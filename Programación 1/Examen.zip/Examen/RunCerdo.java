public class RunCerdo {
    public static void main(String[] args) {
        // Crear una instancia de la clase Cerdo
        CerdoMetodos juegoCerdo = new CerdoMetodos();
        System.out.println("Cami Rgz - C36624");
        // Llamar al método Ronda() en la instancia del juego
        juegoCerdo.Ronda();
        System.out.println("Cami Rgz - C36624");
    }
}
